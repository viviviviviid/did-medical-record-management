
// 특정 비밀번호를 주고 받는다던지
// 유효기간을 준다던지
const requestLink_QR = async (req, res) => {
  try{
    const jwt = req.body.jwt
    const password = req.body.password

    return result 
  }catch(error){
    console.log("requestLink_QR function error: ", error)
    return res.status(400).send(error);
  }
}