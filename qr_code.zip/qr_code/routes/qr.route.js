import controller from "../qr.controller.js";
import express from "express";
const router = express.Router();

router.post("/link", controller.requestLink_QR);
router.get("/jwt", controller.@@@);

export default router;