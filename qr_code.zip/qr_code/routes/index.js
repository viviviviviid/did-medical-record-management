import qr from "./qr.route.js";

export default (app) => {
  app.use("/qr", qr);
};
